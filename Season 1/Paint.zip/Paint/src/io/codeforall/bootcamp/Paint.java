package io.codeforall.bootcamp;

public class Paint {
    private PaintCanvas paintCanvas;


}
