package io.codeforall.bootcamp;

public class Main {

    public static void main(String[] args) {

        PaintCanvas paintCanvas = new PaintCanvas(20, 20);
    }
}